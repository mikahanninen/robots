# pylint: disable=missing-class-docstring
import logging
import platform


if platform.system() == "Windows":
    from SapGuiLibrary import SapGuiLibrary
    from pythoncom import com_error
else:

    class SapGuiLibrary:
        """Keywords are only available in Windows."""

        def __init__(self, *args, **kwargs):
            del args, kwargs


class SAP(SapGuiLibrary):
    __doc__ = (
        "This library wraps the upstream "
        "[https://frankvanderkuur.github.io/SapGuiLibrary.html|SapGuiLibrary]."
        "\n\n" + SapGuiLibrary.__doc__
    )

    ROBOT_LIBRARY_SCOPE = "GLOBAL"

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.logger = logging.getLogger(__name__)

        if platform.system() != "Windows":
            self.logger.warning("SAP requires Windows dependencies to work.")

    def get_cell_value(self, table_id, row_num, col_id):
        """Returns the cell value for the specified cell."""
        self.element_should_be_present(table_id)

        try:
            cellValue = self.session.findById(table_id).getCell(row_num, col_id).text
            return cellValue
        except com_error:
            self.take_screenshot()
            message = "Cannot find Column_id '%s'." % col_id
            raise ValueError(message)
