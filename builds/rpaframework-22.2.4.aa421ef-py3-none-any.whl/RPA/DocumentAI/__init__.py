"""Intelligent Document Processing base package."""


from .DocumentAI import DocumentAI
